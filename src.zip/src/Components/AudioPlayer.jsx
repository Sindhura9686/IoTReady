
import { useEffect, useState, useRef } from "react";

const AudioPlayer = ({ audioFiles, currentAudioIndex, setCurrentAudioIndex }) => {
  const audioRef = useRef(new Audio());
  const [isPlaying, setIsPlaying] = useState(false);

  const playNextSong = () => {
    setIsPlaying(false);

    // Determine the index of the next song with looping
    const nextIndex = (currentAudioIndex + 1) % audioFiles.length;
    setCurrentAudioIndex(nextIndex);
  };

  const togglePlayPause = () => {
    const currentAudio = audioRef.current;

    if (currentAudio.paused || currentAudio.ended) {
      currentAudio.play().then(() => {
        setIsPlaying(true);
      }).catch(error => {
        console.error("Error playing audio:", error);
      });
    } else {
      currentAudio.pause();
      setIsPlaying(false);
    }
  };

  const playAudio = () => {
    const currentAudio = audioRef.current;

    // Pause the current audio before starting a new one
    currentAudio.pause();

    // Create a new audio instance for the current track
    const newAudio = new Audio(audioFiles[currentAudioIndex].url);
    audioRef.current = newAudio;

    // Set up event listeners for the new audio instance
    newAudio.addEventListener('ended', playNextSong);

    // Play the new audio
    newAudio.play().then(() => {
      setIsPlaying(true);
    }).catch(error => {
      console.error("Error playing audio:", error);
    });
  };

  useEffect(() => {
    localStorage.setItem('currentAudioIndex', currentAudioIndex);

    // Play the audio when the component mounts or the track changes
    playAudio();

    // Cleanup function
    return () => {
      const currentAudio = audioRef.current;

      // Pause and remove event listeners for the current audio when the component unmounts or the track changes
      currentAudio.pause();
      currentAudio.removeEventListener('ended', playNextSong);
    };
  }, [currentAudioIndex, audioFiles, setCurrentAudioIndex]);

  // Handle changes in the isPlaying state
  useEffect(() => {
    const currentAudio = audioRef.current;

    if (isPlaying) {
      currentAudio.play().catch(error => {
        console.error("Error playing audio:", error);
      });
    } else {
      currentAudio.pause();
    }
  }, [isPlaying]);

  return (
    <div>
      <h2>Now Playing: {audioFiles[currentAudioIndex].name}</h2>
      <div className="audio-instance">
        <audio
          controls
          autoPlay
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
        >
          <source src={audioFiles[currentAudioIndex].url} type="audio/mp3" />
          Your browser does not support the audio tag.
        </audio>
        <button onClick={togglePlayPause}>{isPlaying ? 'Pause' : 'Play'}</button>
      </div>
    </div>
  );
};

export default AudioPlayer;

